document.addEventListener('DOMContentLoaded', function() {

  const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
  };

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = '1';
        entry.target.style.transform = 'translateY(0)';
      }
    });
  }, observerOptions);

  document.querySelectorAll('.fade-up').forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(30px)';
    el.style.transition = 'opacity 0.8s ease, transform 0.8s ease';
    observer.observe(el);
  });

  const scrollToTopBtn = document.getElementById('scrollToTop');

  if (scrollToTopBtn) {
    window.addEventListener('scroll', () => {
      if (window.pageYOffset > 300) {
        scrollToTopBtn.classList.add('visible');
      } else {
        scrollToTopBtn.classList.remove('visible');
      }
    });

    scrollToTopBtn.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  const header = document.querySelector('.site-header');
  if (header) {
    window.addEventListener('scroll', () => {
      if (window.scrollY > 50) {
        header.classList.add('scrolled');
      } else {
        header.classList.remove('scrolled');
      }
    });
  }

  const contactForm = document.getElementById('contactForm');
  if (contactForm) {
    contactForm.addEventListener('submit', function(e) {
      e.preventDefault();

      const name = document.getElementById('name').value.trim();
      const email = document.getElementById('email').value.trim();
      const subject = document.getElementById('subject').value.trim();
      const message = document.getElementById('message').value.trim();

      const formStatus = document.getElementById('formStatus');

      if (!name || !email || !subject || !message) {
        formStatus.className = 'form-status error';
        formStatus.textContent = 'Please fill in all fields.';
        return;
      }

      if (!email.includes('@') || !email.includes('.')) {
        formStatus.className = 'form-status error';
        formStatus.textContent = 'Please enter a valid email address.';
        return;
      }

      const whatsappMessage = `Name: ${name}%0AEmail: ${email}%0ASubject: ${subject}%0AMessage: ${message}`;
      const whatsappUrl = `https://wa.me/923262506314?text=${whatsappMessage}`;

      formStatus.className = 'form-status success';
      formStatus.textContent = 'Opening WhatsApp...';

      setTimeout(() => {
        window.open(whatsappUrl, '_blank');
        formStatus.textContent = 'Message sent! Thank you for contacting me.';
        contactForm.reset();
      }, 1000);
    });
  }

  const profilePic = document.getElementById('profilePic');
  const popup = document.getElementById('imgPopup');
  const popupImage = document.getElementById('popupImage');
  const closeBtn = document.querySelector('.close');

  if (profilePic && popup && popupImage && closeBtn) {
    profilePic.addEventListener('click', function() {
      popupImage.src = this.src;
      popup.classList.add('show');
      document.body.style.overflow = 'hidden';
    });

    closeBtn.addEventListener('click', () => {
      popup.classList.remove('show');
      document.body.style.overflow = 'auto';
    });

    popup.addEventListener('click', (e) => {
      if (e.target === popup) {
        popup.classList.remove('show');
        document.body.style.overflow = 'auto';
      }
    });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && popup.classList.contains('show')) {
        popup.classList.remove('show');
        document.body.style.overflow = 'auto';
      }
    });
  }

  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
      const href = this.getAttribute('href');
      if (href === '#') return;

      const targetElement = document.querySelector(href);
      if (targetElement) {
        e.preventDefault();

        if (href === '#contact' && window.location.pathname !== '/') {
          window.location.href = 'index.html' + href;
          return;
        }

        window.scrollTo({
          top: targetElement.offsetTop - 80,
          behavior: 'smooth'
        });
      }
    });
  });

  const hamburger = document.getElementById('hamburger');
  const navLinks = document.querySelector('.nav-links');

  if (hamburger && navLinks) {
    hamburger.addEventListener('click', () => {
      navLinks.classList.toggle('open');
      hamburger.classList.toggle('active');
    });

    navLinks.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        navLinks.classList.remove('open');
        hamburger.classList.remove('active');
      });
    });
  }

  const yearElements = document.querySelectorAll('[id^="year"]');
  const currentYear = new Date().getFullYear();
  yearElements.forEach(el => {
    el.textContent = currentYear;
  });

  document.querySelectorAll('.project-image img, .project-thumb img').forEach(img => {
    img.addEventListener('error', function() {
      const card = this.closest('.project-card, .project-card-home');
      let projectName = 'Project';
      if (card) {
        const title = card.querySelector('h3');
        if (title) projectName = title.textContent;
      }
      this.src = `https://via.placeholder.com/600x400?text=${encodeURIComponent(projectName)}`;
    });
  });

  console.log('Portfolio loaded successfully!');
});